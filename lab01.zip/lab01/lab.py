#!/usr/bin/env python3

import math

from PIL import Image as Image

# NO ADDITIONAL IMPORTS ALLOWED!


def get_pixel(image, x, y):
    return image['pixels'][x*image['width']+y]


def set_pixel(image, x, y, c):
    image['pixels'][x*image['width']+y] = c


def apply_per_pixel(image, func):
    result = {
        'height': image['height'],
        'width': image['width'],
        'pixels': [1]*image['height']*image['width'],
    }

    for x in range(image['height']):
        for y in range(image['width']):

            color = get_pixel(image, x, y)
            newcolor = func(color)
            set_pixel(result, x,y, newcolor)
    return result


def inverted(image):
    return apply_per_pixel(image, lambda c: 255-c)


# HELPER FUNCTIONS

def correlate(image, kernel):
    """
    Compute the result of correlating the given image with the given kernel.

    The output of this function should have the same form as a 6.009 image (a
    dictionary with 'height', 'width', and 'pixels' keys), but its pixel values
    do not necessarily need to be in the range [0,255], nor do they need to be
    integers (they should not be clipped or rounded at all).

    This process should not mutate the input image; rather, it should create a
    separate structure to represent the output.

    Represent kernel as a list

    1. 计算长宽 2. 计算影响范围，即长宽/2 3. 我们从左上角的第一个像素点开始计算。 4. 对像素点进行计算。 5. 把计算结果放入 result
    """
    width=int(len(kernel)**0.5)

    distance_from_center=width//2

    newimage={
        'height': image['height'],
        'width': image['width'],
        'pixels': []
    }



    for x in range(image['height']):
        for y in range(image['width']):
            sum=0
            for x1 in range(x-distance_from_center, x+distance_from_center+1):
                for y1 in range(y-distance_from_center, y+distance_from_center+1):
                    kernel_value = kernel[(y1 - y + distance_from_center) +
                                          (x1 - x + distance_from_center)*width]
                    a,b=x1,y1

                    if a<0:
                        a=0
                    elif a>=image['height']:
                        a=image['height']-1
                    if b<0:
                        b=0
                    elif b>=image['width']:
                        b=image['width']-1

                    sum+=kernel_value*get_pixel(image, a,b)


            newimage['pixels'].append(sum)



    return newimage


def round_and_clip_image(image):
    """
    Given a dictionary, ensure that the values in the 'pixels' list are all
    integers in the range [0, 255].

    All values should be converted to integers using Python's `round` function.

    Any locations with values higher than 255 in the input should have value
    255 in the output; and any locations with values lower than 0 in the input
    should have value 0 in the output.
    """
    for x in range(image['height']):
        for y in range(image['width']):

            color = get_pixel(image, x, y)
            if color<0:
                set_pixel(image, x, y, 0)
            elif color>255:
                set_pixel(image, x, y, 255)
            else:
                set_pixel(image, x, y, round(color))

    return image





# FILTERS

def blurred(image, n):
    """
    Return a new image representing the result of applying a box blur (with
    kernel size n) to the given input image.

    This process should not mutate the input image; rather, it should create a
    separate structure to represent the output.
    """
    # first, create a representation for the appropriate n-by-n kernel (you may
    # wish to define another helper function for this)
    kernel=[]

    for i in range(n):
        for j in range(n):
            kernel.append(1/(n**2))


    # then compute the correlation of the input image with that kernel
    newimage=correlate(image, kernel)

    # and, finally, make sure that the output is a valid image (using the
    # helper function from above) before returning it.
    return round_and_clip_image(newimage)

def blurredwithoutrounding(image, n):
    """
    Return a new image representing the result of applying a box blur (with
    kernel size n) to the given input image.

    This process should not mutate the input image; rather, it should create a
    separate structure to represent the output.
    """
    # first, create a representation for the appropriate n-by-n kernel (you may
    # wish to define another helper function for this)
    kernel=[]

    for i in range(n):
        for j in range(n):
            kernel.append(1/(n**2))


    # then compute the correlation of the input image with that kernel
    newimage=correlate(image, kernel)

    # and, finally, make sure that the output is a valid image (using the
    # helper function from above) before returning it.
    return newimage

def edges(image):
    """
    Return a new image with the edges emphasized. Apply two kernels respectively

    """
    kernel_x=[-1, 0, 1, -2, 0, 2, -1, 0, 1]
    kernel_y=[-1, -2, -1, 0, 0, 0, 1, 2, 1]

    output_x=correlate(image, kernel_x)
    output_y=correlate(image, kernel_y)

    output={'height': image['height'],
    'width': image['width'],
    'pixels': []}
    for x in range(image['height']):
        for y in range(image['width']):
            pix_x=get_pixel(output_x, x, y)
            pix_y=get_pixel(output_y, x, y)
            newpixel=round(math.sqrt(pix_x**2+pix_y**2))
            output['pixels'].append(newpixel)
    return round_and_clip_image(output)


def sharpened(image, n):
    """
        Return a new image representing the result of sharpening the image with
        a box blur (with
        kernel size n) to the given input image.

        This process should not mutate the input image; rather, it should create a
        separate structure to represent the output.
        """
    blur_version=blurredwithoutrounding(image, n)
    double_version=apply_per_pixel(image, lambda c: c*2)
    newimage={'height': image['height'],
    'width': image['width'],
    'pixels': []}

    for x in range(image['height']):
        for y in range(image['width']):
            blur=get_pixel(blur_version, x, y)
            double=get_pixel(double_version, x, y)

            newimage['pixels'].append(double-blur)

    return round_and_clip_image(newimage)


# HELPER FUNCTIONS FOR LOADING AND SAVING IMAGES

def load_image(filename):
    """
    Loads an image from the given file and returns a dictionary
    representing that image.  This also performs conversion to greyscale.

    Invoked as, for example:
       i = load_image('test_images/cat.png')
    """
    with open(filename, 'rb') as img_handle:
        img = Image.open(img_handle)
        img_data = img.getdata()
        if img.mode.startswith('RGB'):
            pixels = [round(.299 * p[0] + .587 * p[1] + .114 * p[2])
                      for p in img_data]
        elif img.mode == 'LA':
            pixels = [p[0] for p in img_data]
        elif img.mode == 'L':
            pixels = list(img_data)
        else:
            raise ValueError('Unsupported image mode: %r' % img.mode)
        w, h = img.size
        return {'height': h, 'width': w, 'pixels': pixels}


def save_image(image, filename, mode='PNG'):
    """
    Saves the given image to disk or to a file-like object.  If filename is
    given as a string, the file type will be inferred from the given name.  If
    filename is given as a file-like object, the file type will be determined
    by the 'mode' parameter.
    """
    out = Image.new(mode='L', size=(image['width'], image['height']))
    out.putdata(image['pixels'])
    if isinstance(filename, str):
        out.save(filename)
    else:
        out.save(filename, mode)
    out.close()


if __name__ == '__main__':
    # code in this block will only be run when you explicitly run your script,
    # and not when the tests are being run.  this is a good place for
    # generating images, etc.
    # image=load_image("test_images/pigbird.png")
    # kernel= [0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          1, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0,
    #          0, 0, 0, 0, 0, 0, 0, 0, 0]
    # newimage=correlate(image, kernel)
    # newimage=round_and_clip_image(newimage)
    # save_image(newimage, "test_images/pigbirdaddedkernel.png")

    # image = load_image("test_images/cat.png")
    # newimage=blurred(image, 5)
    # save_image(newimage, "test_images/catblurred.png")
    # image=load_image("test_images/python.png")
    # newimage=sharpened(image, 11)
    # save_image(newimage, "test_images/pythonsharpened.png")
    # image=load_image("test_images/construct.png")
    # newimage=edges(image)
    # save_image(newimage, "test_images/constructedges.png")
    image=load_image("test_images/centered_pixel.png")
    newimage=blurred(image, 1)
    newimage=blurred(newimage, 3)
    print(newimage['width'])
    print(newimage['height'])
    print(newimage['pixels'])
