#!/usr/bin/env python3
"""6.009 Lab 8: Snek Interpreter"""

import doctest


# NO ADDITIONAL IMPORTS!


###########################
# Snek-related Exceptions
###########################


class SnekError(Exception):
    """
    A type of exception to be raised if there is an error with a Snek
    program.  Should never be raised directly; rather, subclasses should be
    raised.
    """
    pass


class SnekSyntaxError(SnekError):
    """
    Exception to be raised when trying to evaluate a malformed expression.
    """
    pass


class SnekNameError(SnekError):
    """
    Exception to be raised when looking up a name that has not been defined.
    """
    pass


class SnekEvaluationError(SnekError):
    """
    Exception to be raised if there is an error during evaluation other than a
    SnekNameError.
    """
    pass


############################
# Tokenization and Parsing #
############################


def number_or_symbol(x):
    """
    Helper function: given a string, convert it to an integer or a float if
    possible; otherwise, return the string itself

    >>> number_or_symbol('8')
    8
    >>> number_or_symbol('-5.32')
    -5.32
    >>> number_or_symbol('1.2.3.4')
    '1.2.3.4'
    >>> number_or_symbol('x')
    'x'
    """
    try:
        return int(x)
    except ValueError:
        try:
            return float(x)
        except ValueError:
            return x


def tokenize(source):
    """
    Splits an input string into meaningful tokens (left parens, right parens,
    other whitespace-separated values).  Returns a list of strings.

    Arguments:
        source (str): a string containing the source code of a Snek
                      expression
    """
    tokens = []
    index, n = 0, len(source)
    while index < n:
        ch = source[index]
        j = index + 1
        if ch == ';':
            while j < n and source[j] != '\n':
                j += 1
            j += 1
        elif ch in '()':
            tokens.append(ch)
        elif ch not in ' \n':
            while j < n and source[j] not in ' \n;()':
                j += 1
            tokens.append(source[index:j])
        index = j
    return tokens


def parse(tokens):
    """
    Parses a list of tokens, constructing a representation where:
        * symbols are represented as Python strings
        * numbers are represented as Python ints or floats
        * S-expressions are represented as Python lists

    Arguments:
        tokens (list): a list of strings representing tokens
    """
    index, n = 0, len(tokens)
    #lst is a list
    #check if it is a list of strings of at least length k
    def is_params(lst, k=0):
        if not isinstance(lst, list) or len(lst) < k:
            return False
        for e in lst:
            if not isinstance(e, str):
                return False
        return True

    def construct_node():
        nonlocal index #get the closest one step up
        #check whether or not the current node has bracket
        has_bracket = False
        if index < n and tokens[index] == '(':
            has_bracket = True
            index += 1

        #ex. (+2 (-3 3)
        cur_node = []
        while index < n and tokens[index] != ')':
            if tokens[index] == '(':
                #make a new node, a subtree
                cur_node.append(construct_node())
            else:
                # turn it into a string or a number
                cur_node.append(number_or_symbol(tokens[index]))
                index += 1

        if len(cur_node) >= 1:
            if cur_node[0] == 'define':
                #define has to satisfy two things
                # it needs openning bracket and have a length of 3
                #it also needs that the first argument passed in is either a string or a list of strings of length >>1
                if not (has_bracket and len(cur_node) == 3 and
                        (isinstance(cur_node[1], str) or is_params(cur_node[1], 1))):
                    raise SnekSyntaxError

            elif cur_node[0] == 'lambda':
                #for lambda, it can pass in empty argument, list of strings of length>=0
                if not (has_bracket and len(cur_node) == 3 and is_params(cur_node[1])):
                    raise SnekSyntaxError

        if has_bracket:
            #check if has a corresponding right parenthesis at the end
            if index < n and tokens[index] == ')':
                index += 1
                return cur_node
            raise SnekSyntaxError
        else:
            # ex. parse(['x'])
            if len(cur_node) == 1:
                return cur_node[0]
            #raise error if no beginning parenthesis and length>1, like + 2 3
            raise SnekSyntaxError

    node = construct_node()
    # ex (+ 2 3) ((( then it has syntax error
    if index < n:
        raise SnekSyntaxError
    return node


######################
# Built-in Functions #
######################
def mul(lst):
    p = 1
    for i in lst:
        p *= i
    return p


snek_builtins = {
    "+": sum,
    "-": lambda args: -args[0] if len(args) == 1 else (args[0] - sum(args[1:])),
    "*": mul,
    "/": lambda args: args[0] if len(args) == 1 else (args[0] / mul(args[1:])),
}


##############
# Evaluation #
##############
class Environment:

    def __init__(self, parent=None):
        # if no parent, then parent is just the builtin
        if parent is None:
            parent = snek_builtins
        self.parent = parent
        self.variables = dict()

    def __contains__(self, x):
        val = self.get(x)
        # check if it is None
        return val is not None

    def __getitem__(self, x):
        val = self.get(x)
        if val is None:
            raise KeyError
        return val

    def get(self, x):
        cur = self
        while True:
            if x in cur.variables:
                return cur.variables[x]
            cur = cur.parent
            if cur is snek_builtins:
                break
        # if in builtin, return get x in builtin, otherwise return None
        return snek_builtins.get(x, None)

    def __setitem__(self, key, value):
        self.variables[key] = value


class Function:
    def __init__(self, params, tree, env):
        #tree is the expression tree passed in
        self.params = params
        self.tree = tree
        self.parent_env = env

    def __call__(self, lst):
        if len(lst) != len(self.params):
            raise SnekEvaluationError
        local_env = Environment(self.parent_env)
        for param, value in zip(self.params, lst):
            local_env[param] = value
        return evaluate(self.tree, local_env)


def evaluate(tree, env=None):
    """
    Evaluate the given syntax tree according to the rules of the Snek
    language.

    Arguments:
        tree (type varies): a fully parsed expression, as the output from the
                            parse function
        env : environment
    """

    if env is None:
        env = Environment()
        #first check some special cases
    if isinstance(tree, (int, float)):
        return tree
    if isinstance(tree, str):
        if tree in env:
            return env[tree]
        raise SnekNameError

    if tree[0] == 'define':
        #ex. def x (+ 2 3)
        if isinstance(tree[1], str):
            name = tree[1]
            value = evaluate(tree[2], env)
        else:
        # ex (define (square x) (* x x))
            name = tree[1][0]
            # parameter is x
            value = Function(tree[1][1:], tree[2], env)
        env[name] = value
        return value

    # ex. [lambda, [x,y], [+ x y]]
    if tree[0] == 'lambda':
        params = tree[1]
        return Function(params, tree[2], env)
    # ex. [+ 2 3 ]
    # function is in the builtin, sum
    function = evaluate(tree[0], env) if isinstance(tree[0], list) else env.get(tree[0])
    #check if this object is a callable function
    if not callable(function):
        raise SnekEvaluationError
    #value list is 2, 3 here
    value_list = [evaluate(val, env) for val in tree[1:]]
    # let the function act on the value list
    return function(value_list)


def result_and_env(tree, env=None):
    if env is None:
        env = Environment()
    return evaluate(tree, env), env


if __name__ == "__main__":
    # code in this block will only be executed if lab.py is the main file being
    # run (not when this module is imported)

    # uncommenting the following line will run doctests from above
    # doctest.testmod()

    env = Environment()
    while True:
        text = input("in> ")
        if text == "QUIT":
            break
        try:
            tokens = tokenize(text)
            tree = parse(tokens)
            res = evaluate(tree, env)
            print(f"out> {res}")
        except Exception as e:
            print(repr(e))
