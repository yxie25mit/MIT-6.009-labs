"""6.009 Lab 9: Snek Interpreter Part 2"""

import sys

sys.setrecursionlimit(10_000)

import doctest


# NO ADDITIONAL IMPORTS!


###########################
# Snek-related Exceptions #
###########################


class SnekError(Exception):
    """
    A type of exception to be raised if there is an error with a Snek
    program.  Should never be raised directly; rather, subclasses should be
    raised.
    """
    pass


class SnekSyntaxError(SnekError):
    """
    Exception to be raised when trying to evaluate a malformed expression.
    """
    pass


class SnekNameError(SnekError):
    """
    Exception to be raised when looking up a name that has not been defined.
    """
    pass


class SnekEvaluationError(SnekError):
    """
    Exception to be raised if there is an error during evaluation other than a
    SnekNameError.
    """
    pass


############################
# Tokenization and Parsing #
############################


def number_or_symbol(x):
    """
    Helper function: given a string, convert it to an integer or a float if
    possible; otherwise, return the string itself

    >>> number_or_symbol('8')
    8
    >>> number_or_symbol('-5.32')
    -5.32
    >>> number_or_symbol('1.2.3.4')
    '1.2.3.4'
    >>> number_or_symbol('x')
    'x'
    """
    try:
        return int(x)
    except ValueError:
        try:
            return float(x)
        except ValueError:
            return x


def tokenize(source):
    """
    Splits an input string into meaningful tokens (left parens, right parens,
    other whitespace-separated values).  Returns a list of strings.

    Arguments:
        source (str): a string containing the source code of a Snek
                      expression
    """
    tokens = []
    index, n = 0, len(source)
    while index < n:
        ch = source[index]
        j = index + 1
        if ch == ';':
            while j < n and source[j] != '\n':
                j += 1
            j += 1
        elif ch in '()':
            tokens.append(ch)
        elif ch not in ' \n':
            while j < n and source[j] not in ' \n;()':
                j += 1
            tokens.append(source[index:j])
        index = j
    return tokens


def is_params(lst, type_list=str, k=0):
    if not isinstance(lst, list) or len(lst) < k:
        return False
    return all(isinstance(e, type_list) for e in lst)


def parse(tokens):
    """
    Parses a list of tokens, constructing a representation where:
        * symbols are represented as Python strings
        * numbers are represented as Python ints or floats
        * S-expressions are represented as Python lists

    Arguments:
        tokens (list): a list of strings representing tokens
    """
    index, n = 0, len(tokens)

    def construct_node():
        nonlocal index

        has_bracket = False
        if index < n and tokens[index] == '(':
            has_bracket = True
            index += 1

        cur_node = []
        while index < n and tokens[index] != ')':
            if tokens[index] == '(':
                cur_node.append(construct_node())
            else:
                cur_node.append(number_or_symbol(tokens[index]))
                index += 1

        if len(cur_node) >= 1:
            key = cur_node[0]
            if key == 'define':
                if not (has_bracket and len(cur_node) == 3 and
                        (isinstance(cur_node[1], str) or is_params(cur_node[1], k=1))):
                    raise SnekSyntaxError
            elif key == 'lambda':
                if not (has_bracket and len(cur_node) == 3 and is_params(cur_node[1])):
                    raise SnekSyntaxError
            elif key == 'if':
                if not (has_bracket and len(cur_node) == 4):
                    raise SnekSyntaxError

        if has_bracket:
            if index < n and tokens[index] == ')':
                index += 1
                return cur_node
            raise SnekSyntaxError
        else:
            if len(cur_node) == 1:
                return cur_node[0]
            raise SnekSyntaxError

    node = construct_node()
    if index < n:
        raise SnekSyntaxError
    return node


######################
# Built-in Functions #
######################
def mul(lst):
    p = 1
    for i in lst:
        p *= i
    return p

# x0<x1<x2, x0x1x2, x1x2, zip these two
def strictly_increasing(lst):
    if not is_params(lst, type_list=(int, float)):
        raise SnekEvaluationError
    return all(x < y for x, y in zip(lst, lst[1:]))


def strictly_decreasing(lst):
    if not is_params(lst, type_list=(int, float)):
        raise SnekEvaluationError
    return all(x > y for x, y in zip(lst, lst[1:]))


def non_increasing(lst):
    if not is_params(lst, type_list=(int, float)):
        raise SnekEvaluationError
    return all(x >= y for x, y in zip(lst, lst[1:]))


def non_decreasing(lst):
    if not is_params(lst, type_list=(int, float)):
        raise SnekEvaluationError
    return all(x <= y for x, y in zip(lst, lst[1:]))


def all_equal(lst):
    if len(lst) == 0:
        raise SnekEvaluationError
    first = lst[0]
    return all(first == x for x in lst)


def negate(lst):
    if len(lst) != 1 or not isinstance(lst[0], bool):
        raise SnekEvaluationError
    return not lst[0]


def _head(lst):
    if len(lst) != 1 or not isinstance(lst[0], Pair):
        raise SnekEvaluationError
    return lst[0].head


def _tail(lst):
    if len(lst) != 1 or not isinstance(lst[0], Pair):
        raise SnekEvaluationError
    return lst[0].tail

#distinguish between linked list and pair
def _create_pair(lst):
    if len(lst) != 2:
        raise SnekEvaluationError
    if lst[1] is None or isinstance(lst[1], LinkedList):
        return LinkedList(lst[0], lst[1])
    return Pair(lst[0], lst[1])


def _create_list(lst):
    if not lst:
        return None
    head = LinkedList(lst[0])
    cur = head
    for ele in lst[1:]:
        cur.tail = LinkedList(ele)
        cur = cur.tail
    return head


def _length(lst):
    if not (len(lst) == 1 and (isinstance(lst[0], LinkedList) or lst[0] is None)):
        raise SnekEvaluationError
    count = 0
    cur = lst[0]
    while cur:
        count += 1
        cur = cur.tail
    return count


def _nth(lst):
    if not (len(lst) == 2 and isinstance(lst[0], Pair) and isinstance(lst[1], int) and lst[1] >= 0):
        raise SnekEvaluationError
    cur, k = lst
    if isinstance(lst[0], LinkedList):
        while cur and k:
            cur = cur.tail
            k -= 1
        if not cur:
            raise SnekEvaluationError
    elif k != 0:
        raise SnekEvaluationError
    return cur.head


#dummy has None as the head and its tail is the desired
def _concat(lst):
    if len(lst) == 0:
        return None
    if not all(isinstance(x, LinkedList) or x is None for x in lst):
        raise SnekEvaluationError
    dummy = LinkedList()
    cur1 = dummy
    for cur2 in lst:
        while cur2:
            cur1.tail = LinkedList(cur2.head)
            cur2 = cur2.tail
            cur1 = cur1.tail
    return dummy.tail


def _map(lst):
    if not (len(lst) == 2 and callable(lst[0]) and (isinstance(lst[1], LinkedList) or lst[1] is None)):
        raise SnekEvaluationError
    if not lst[1]:
        return None
    dummy = LinkedList()
    cur1 = dummy
    func, cur2 = lst
    while cur2:
        cur1.tail = LinkedList(func([cur2.head]))
        cur2 = cur2.tail
        cur1 = cur1.tail
    return dummy.tail


def _filter(lst):
    if not (len(lst) == 2 and callable(lst[0]) and (isinstance(lst[1], LinkedList) or lst[1] is None)):
        raise SnekEvaluationError
    if not lst[1]:
        return None
    dummy = LinkedList()
    cur1 = dummy
    func, cur2 = lst
    while cur2:
        if func([cur2.head]):
            cur1.tail = LinkedList(cur2.head)
            cur1 = cur1.tail
        cur2 = cur2.tail
    return dummy.tail


def _reduce(lst):
    if not (len(lst) == 3 and callable(lst[0]) and (isinstance(lst[1], LinkedList) or lst[1] is None)):
        raise SnekEvaluationError
    func, cur, init = lst
    while cur:
        init = func([init, cur.head])
        cur = cur.tail
    return init


def _begin(lst):
    if lst:
        return lst[-1]


snek_builtins = {
    "+": sum,
    "-": lambda args: -args[0] if len(args) == 1 else (args[0] - sum(args[1:])),
    "*": mul,
    "/": lambda args: args[0] if len(args) == 1 else (args[0] / mul(args[1:])),
    "=?": all_equal,
    ">": strictly_decreasing,
    ">=": non_increasing,
    "<": strictly_increasing,
    "<=": non_decreasing,
    "not": negate,
    "#t": True,
    "#f": False,
    "head": _head,
    "tail": _tail,
    "nil": None,
    "pair": _create_pair,
    "list": _create_list,
    "length": _length,
    "nth": _nth,
    "concat": _concat,
    "map": _map,
    "filter": _filter,
    "reduce": _reduce,
    "begin": _begin
}


##############
# Evaluation #
##############
class Environment:

    def __init__(self, parent=None):
        if parent is None:
            parent = snek_builtins
        self.parent = parent
        self.variables = dict()

    def __contains__(self, x):
        variables = self.get_env_variables(x)
        return x in variables

    def __getitem__(self, x):
        variables = self.get_env_variables(x)
        if x not in variables:
            raise KeyError
        return variables[x]

    def get(self, x):
        variables = self.get_env_variables(x)
        return variables.get(x, None)

    def get_env_variables(self, x):
        cur = self
        while True:
            if x in cur.variables:
                return cur.variables
            cur = cur.parent
            if cur is snek_builtins:
                break
        return snek_builtins

    def __setitem__(self, key, value):
        self.variables[key] = value


class Function:
    def __init__(self, params, tree, env):
        self.params = params
        self.tree = tree
        self.parent_env = env

    def __call__(self, lst):
        if len(lst) != len(self.params):
            raise SnekEvaluationError
        local_env = Environment(self.parent_env)
        for param, value in zip(self.params, lst):
            local_env[param] = value
        return evaluate(self.tree, local_env)


class Pair:
    def __init__(self, head=None, tail=None):
        self.head = head
        self.tail = tail


class LinkedList(Pair):
    def __init__(self, head=None, tail=None):
        super().__init__(head, tail)


def evaluate(tree, env=None):
    """
    Evaluate the given syntax tree according to the rules of the Snek
    language.

    Arguments:
        tree (type varies): a fully parsed expression, as the output from the
                            parse function
        env : environment
    """
    if env is None:
        env = Environment()
    if isinstance(tree, (int, float)):
        return tree
    if isinstance(tree, str):
        if tree in env:
            return env[tree]
        raise SnekNameError

    if len(tree) == 0:
        raise SnekEvaluationError

    key = tree[0]
    if key == 'define':
        if isinstance(tree[1], str):
            name = tree[1]
            value = evaluate(tree[2], env)
        else:
            name = tree[1][0]
            value = Function(tree[1][1:], tree[2], env)
        env[name] = value
        return value
    if key == 'lambda':
        params = tree[1]
        return Function(params, tree[2], env)
    if key == 'if':
        cond = evaluate(tree[1], env)
        return evaluate(tree[2], env) if cond else evaluate(tree[3], env)
    if key == 'and':
        for val in tree[1:]:
            val = evaluate(val, env)
            if not isinstance(val, bool):
                raise SnekEvaluationError
            if not val:
                return False
        return True
    if key == 'or':
        for val in tree[1:]:
            val = evaluate(val, env)
            if not isinstance(val, bool):
                raise SnekEvaluationError
            if val:
                return True
        return False
    if key == 'del':
        if not (len(tree) == 2 and isinstance(tree[1], str)):
            raise SnekEvaluationError
        variables = env.variables
        if tree[1] not in variables:
            raise SnekNameError
        val = variables[tree[1]]
        del variables[tree[1]]
        return val
    if key == 'let':
        if not (len(tree) == 3 and all(isinstance(x, list) for x in tree[1])):
            raise SnekEvaluationError
        var_list = tree[1]
        if not (all(len(x) == 2 and isinstance(x[0], str) for x in var_list)):
            raise SnekEvaluationError
        local_env = Environment(env)
        for k, v in var_list:
            local_env[k] = evaluate(v, env)
        return evaluate(tree[2], local_env)
    if key == 'set!':
        if not (len(tree) == 3 and isinstance(tree[1], str)):
            raise SnekEvaluationError
        variables = env.get_env_variables(tree[1])
        if tree[1] not in variables:
            raise SnekNameError
        val = evaluate(tree[2], env)
        variables[tree[1]] = val
        return val

    if isinstance(key, list):
        function = evaluate(key, env)
    else:
        if not isinstance(key, str):
            raise SnekEvaluationError
        if key not in env:
            raise SnekNameError
        function = env[key]

    if not callable(function):
        raise SnekEvaluationError

    #ex. if the function here is begin, would return the last argument
    #from evaluating the valuelist
    value_list = [evaluate(val, env) for val in tree[1:]]
    return function(value_list)


def result_and_env(tree, env=None):
    if env is None:
        env = Environment()
    return evaluate(tree, env), env


def evaluate_file(path, env=None):
    with open(path) as f:
        texts = f.readlines()
        texts = "".join(texts)
        if not env:
            env = Environment()
        tokens = tokenize(texts)
        tree = parse(tokens)
        res = evaluate(tree, env)
        return res


def REPL(env=None):
    if env is None:
        env = Environment()
    while True:
        text = input("in> ")
        if text == "QUIT":
            break
        try:
            tokens = tokenize(text)
            tree = parse(tokens)
            res = evaluate(tree, env)
            print(f"out> {res}")
        except Exception as e:
            print(repr(e))


if __name__ == "__main__":
    # code in this block will only be executed if lab.py is the main file being
    # run (not when this module is imported)

    # uncommenting the following line will run doctests from above
    # doctest.testmod()

    import sys
    env = Environment()
    for path in sys.argv[1:]:
        res = evaluate_file(path, env)
        print(res)
    REPL(env)
