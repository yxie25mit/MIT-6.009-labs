"""6.009 Lab 10: Snek Is You Video Game"""

import doctest

# NO ADDITIONAL IMPORTS!

# All words mentioned in lab. You can add words to these sets,
# but only these are guaranteed to have graphics.
NOUNS = {"SNEK", "FLAG", "ROCK", "WALL", "COMPUTER", "BUG"}
PROPERTIES = {"YOU", "WIN", "STOP", "PUSH", "DEFEAT", "PULL"}
WORDS = NOUNS | PROPERTIES | {"AND", "IS"}

# Maps a keyboard direction to a (delta_row, delta_column) vector.
direction_vector = {
    "up": (-1, 0),
    "down": (+1, 0),
    "left": (0, -1),
    "right": (0, +1),
}


def new_game(level_description):
    """
    Given a description of a game state, create and return a game
    representation of your choice.

    The given description is a list of lists of lists of strs, where UPPERCASE
    strings represent word objects and lowercase strings represent regular
    objects (as described in the lab writeup).

    For example, a valid level_description is:

    [
        [[], ['snek'], []],
        [['SNEK'], ['IS'], ['YOU']],
    ]

    The exact choice of representation is up to you; but note that what you
    return will be used as input to the other functions.
    """
    return Game(level_description)


def step_game(game, direction):
    """
    Given a game representation (as returned from new_game), modify that game
    representation in-place according to one step of the game.  The user's
    input is given by direction, which is one of the following:
    {'up', 'down', 'left', 'right'}.

    step_game should return a Boolean: True if the game has been won after
    updating the state, and False otherwise.
    """
    game.move(direction_vector[direction])
    return game.is_win()


def dump_game(game):
    """
    Given a game representation (as returned from new_game), convert it back
    into a level description that would be a suitable input to new_game.

    This function is used by the GUI and tests to see what your game
    implementation has done, and it can also serve as a rudimentary way to
    #print out the current state of your game for testing and debugging on your
    own.
    """
    return game.to_level_description()


class Cell:
    rules = None
    #store its coordinates and the objects it contains
    def __init__(self, x, y, objects):
        self.coordinate = (x, y)
        self.objects = objects

    def contains_property(self, prop):
        return any(prop in Cell.rules.get_properties_of_object_type(obj) for obj in self.objects)

    def contains_object(self, object_type):
        return object_type in self.objects

    def get_objects_with_property(self, prop):
        object_types = Cell.rules.get_object_types_with_property(prop)
        # the intersection of the objects it has and the objects that have the property
        return [obj for obj in self.objects if obj in object_types]

    def get_objects_in_names(self, names):
        if not names:
            return []
        return [obj for obj in self.objects if obj in names]

    def is_win(self):
        #get all the objects with you property
        objects_with_you_property = self.get_objects_with_property("YOU")
        if not objects_with_you_property:
            return False
        if self.contains_property("DEFEAT"):
            #delete all the objects, only let the ones not in objects with you property remain
            self.objects = [obj for obj in self.objects if obj not in objects_with_you_property]
            return False
        if self.contains_property("WIN"):
            return True

    def move(self, objects_with_you_property, direction, board):
        x, y = self.coordinate
        n, m = len(board), len(board[0])
        nx, ny = x + direction[0], y + direction[1]
        if 0 <= nx < n and 0 <= ny < m:
            #aftercell is the cell after one step
            after_cell = board[nx][ny]
            cur_cell = board[x][y]
            # check if aftercell includes the push property
            after_has_push = after_cell.contains_property("PUSH")
            cur_has_pull = cur_cell.contains_property("PULL")
            cur_has_stop = cur_cell.contains_property("STOP")
            #try to push the after cell
            if after_cell.push(direction, board, objects_with_you_property):
                self.objects = [obj for obj in self.objects if obj not in objects_with_you_property]
                #if current has stop, then nothing needs to be done
                if not cur_has_stop:
                    #a special case in the test case
                    if cur_has_pull and after_has_push:
                        pull_out = cur_cell.pull(direction, board)
                        if pull_out:
                            after_cell.objects.extend(pull_out)
                    else:
                        nx, ny = x - direction[0], y - direction[1]
                        if 0 <= nx < n and 0 <= ny < m:
                            previous_cell = board[nx][ny]
                            pull_in = previous_cell.pull(direction, board)
                            if pull_in:
                                self.objects.extend(pull_in)
    # see if the objects are pushable
    def push(self, direction, board, push_in):
        if self.contains_property("STOP"):
            return False
        #get out all the objects with property push
        push_out = self.get_objects_with_property("PUSH")
        #nothing with push property here, can directly overlap
        if not push_out:
            self.objects.extend(push_in)
            return True
        x, y = self.coordinate
        n, m = len(board), len(board[0])
        nx, ny = x + direction[0], y + direction[1]
        #check if the next thing is within the boundary and can return true with
        # the push operation
        if 0 <= nx < n and 0 <= ny < m and board[nx][ny].push(direction, board, push_out):
            #then delete the objects in push out
            self.objects = [obj for obj in self.objects if obj not in push_out]
            #insert in the objects in pushin
            self.objects.extend(push_in)
            return True
        return False
    #pull returns the objects that need to be pulled
    def pull(self, direction, board):
        pull_out = self.get_objects_with_property("PULL")
        if not pull_out:
            return None
        #delete the objects that need to be pulled out
        self.objects = [obj for obj in self.objects if obj not in pull_out]
        if self.contains_property("STOP"):
            return pull_out
        #check if it moves one more step
        x, y = self.coordinate
        n, m = len(board), len(board[0])
        nx, ny = x - direction[0], y - direction[1]
        if 0 <= nx < n and 0 <= ny < m:
            pull_in = board[nx][ny].pull(direction, board)
            if pull_in:
                push_out = self.get_objects_with_property("PUSH")
                self.objects = [obj for obj in self.objects if obj not in push_out]
                self.objects.extend(pull_in)
                pull_out.extend(push_out)
        return pull_out
    # if left is a noun and right is a noun, do replace
    def replace(self):
        for i, obj in enumerate(self.objects):
            if obj in Cell.rules.replacement:
                self.objects[i] = Cell.rules.replacement[obj]

    def to_level_description(self):
        return self.objects


class Rule:
    #use frozenset to prevent from modification
    #can only have push
    WORDS_PROPERTY = frozenset(("PUSH",))

    def __init__(self, board, is_locations):
        #object_type_to_properties maps object type to properties
        self.object_type_to_properties = {w: Rule.WORDS_PROPERTY for w in WORDS}
        #initialize them as empty sets
        for w in NOUNS:
            self.object_type_to_properties[w.lower()] = set()
        #need a reverse map, mapping properties to object types
        self.property_to_object_types = {p: set() for p in PROPERTIES}
        self.property_to_object_types["PUSH"].update(WORDS)
        #replacement dictionary, initialize as empty dict
        self.replacement = dict()
        #first update rules and then simplify the rules
        self.__update_rules(board, is_locations)
        self.__simplify_rules()
    #is locations contains tuples of the locations of "is"
    #update the mappings
    def __update_rules(self, board, is_locations):
        n, m = len(board), len(board[0])

        def get_rule(is_location, direction):
            x, y = is_location
            #scan: pass in two collections and return two
            def scan(_dir, target_names, substitute_names):
                #first get the coordinates of the next location
                nx, ny = x + _dir[0], y + _dir[1]
                targets = set()
                substitute = []
                while 0 <= nx < n and 0 <= ny < m:
                    substitute_collection = board[nx][ny].get_objects_in_names(substitute_names)
                    if substitute_collection:
                        substitute.extend(substitute_collection)
                    else:
                        target_collection = board[nx][ny].get_objects_in_names(target_names)
                        if not target_collection:
                            break
                        targets.update(target_collection)
                    #go another step, move to hte next location
                    nx, ny = nx + _dir[0], ny + _dir[1]
                    if not (0 <= nx < n and 0 <= ny < m and board[nx][ny].contains_object("AND")):
                        break
                    #go one more step and continue the while loop
                    nx, ny = nx + _dir[0], ny + _dir[1]
                return targets, substitute
            #get the three elements, nouns on the left hand side, properties, substitues
            nouns, _ = scan((-direction[0], -direction[1]), NOUNS, set())
            properties, substitute = scan(direction, PROPERTIES, NOUNS)
            return nouns, properties, substitute

        def parse_rule(rules):
            for nouns, properties, substitute in rules:
                if properties:
                    for noun in nouns:
                        self.object_type_to_properties[noun.lower()].update(properties)
                    for prop in properties:
                        for noun in nouns:
                            self.property_to_object_types[prop].add(noun.lower())
                if substitute:
                    #everything inside nouns will be replaced by the first element in substitue
                    for noun in nouns:
                        self.replacement[noun.lower()] = substitute[0].lower()

        rules = []
        for location in is_locations:
            #can vertically and horizontally
            for direction in ((1, 0), (0, 1)):
                nouns, properties, substitute = get_rule(location, direction)
                if nouns:
                    rules.append((nouns, properties, substitute))
        parse_rule(rules)

    def __simplify_rules(self):
        for object_type, props in self.object_type_to_properties.items():
            if object_type in WORDS:
                continue
            if "YOU" in props:
                #if it has property you, delete the following properties
                props -= {"STOP", "PUSH", "PULL"}
                #also remove the objects reversely from the reverse mapping
                self.property_to_object_types["STOP"].discard(object_type)
                self.property_to_object_types["PUSH"].discard(object_type)
                self.property_to_object_types["PULL"].discard(object_type)
            if "PUSH" in props:
                #if it has both push and stop, push has priority
                #so delete stop
                props.discard("STOP")
                self.property_to_object_types["STOP"].discard(object_type)
            if "DEFEAT" in props:
                # defeat has priority over win
                props.discard("WIN")
                self.property_to_object_types["WIN"].discard(object_type)

    def get_properties_of_object_type(self, element):
        return self.object_type_to_properties[element]

    def get_object_types_with_property(self, prop):
        return self.property_to_object_types[prop]


class Game:
    def __init__(self, level_description):
        #get the length and height
        n, m = len(level_description), len(level_description[0])
        self.shape = (n, m)
        #initialze cell for every location
        self.board = [[Cell(i, j, level_description[i][j]) for j in range(m)] for i in range(n)]
        is_locations = self.get_locations_of_object("IS")
        Cell.rules = Rule(self.board, is_locations)

    def get_locations_of_object(self, obj):
        n, m = self.shape
        return [(i, j) for i in range(n) for j in range(m) if obj in self.board[i][j].objects]

    def move(self, direction):
        #first get all object types with property you
        object_types = Cell.rules.get_object_types_with_property("YOU")
        locations_with_you_property = []
        #get all the locations of the objects
        for object_type in object_types:
            locations_with_you_property.extend(self.get_locations_of_object(object_type))

        index = 0 if direction[0] != 0 else 1
        #do sorting with x or y coordinate, do reverse sorting if direction[index] is 1
        locations_with_you_property.sort(key=lambda x: x[index], reverse=direction[index] == 1)
        for location in locations_with_you_property:
            x, y = location
            cell = self.board[x][y]
            objects_with_you_property = cell.get_objects_with_property("YOU")
            cell.move(objects_with_you_property, direction, self.board)

        self.replace_board()
        old_rules = Cell.rules
        is_locations = self.get_locations_of_object("IS")
        Cell.rules = Rule(self.board, is_locations)
        #check if the old rules and new rules have different replacement
        #if different, then need to replace board agan
        if old_rules.replacement != Cell.rules.replacement:
            self.replace_board()

    def replace_board(self):
        n, m = self.shape
        for i in range(n):
            for j in range(m):
                self.board[i][j].replace()

    def is_win(self):
        n, m = self.shape
        return any(self.board[i][j].is_win() for i in range(n) for j in range(m))

    def to_level_description(self):
        n, m = self.shape
        return [[self.board[i][j].to_level_description() for j in range(m)] for i in range(n)]
