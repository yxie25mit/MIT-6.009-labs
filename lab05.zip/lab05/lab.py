#!/usr/bin/env python3
"""6.009 Lab 6 -- Boolean satisfiability solving"""

import sys
sys.setrecursionlimit(10000)


def new_formula(formula, assignment):
    '''
    apply the assignment to the formula and return the updated new formula
    Param: formula: the original CNF formula
            assignment: a dictionary assigning new values
    return: an updated CNF formula
    '''
    new_formula=[]

    for clause in formula:
        #check each pair
        new_clause=[]
        for literal in clause:
            variable, boolval=literal
            # if originally true, assign true, then this clause can be omimtted
            # if originally false, assign false, then this clause can be omitted
            if variable in assignment:
                if boolval==assignment[variable]:
                    # clear this clause and break out of the loop
                    new_clause=[]
                    break
                elif len(clause) == 1:
                    return None
            # if originally true, assign false, or otherwise, this literal can be omitted
            else:
                new_clause.append((variable, boolval))

        if len(new_clause)>0:
            new_formula.append(new_clause)
    return new_formula

def simplify(formula, assignment):
    '''
    find unit clause and then use that to recursively simplify the formula
    Param: formula: the original CNF formula
            assignment: the original assignment of a dictionary assigning new values
    return: simplified version
    '''

    formula=new_formula(formula, assignment)

    #if contradiction, stop immediately

    if formula is None:
        return None

    if len(formula)==0:
        return formula
    return simplifyrecur(formula, assignment)


def simplifyrecur(formula, assignment):
    if formula is None:
        return None
    if len(formula)==0:
        return formula
    #look for unit clause
    for clause in formula:
        if len(clause)==1:
            literal=clause[0]
            variable, boolval=literal
            assignment[variable]=boolval
            formula=new_formula(formula, assignment)
            if formula is None:
                del assignment[variable]
                return None
            return simplify(formula, assignment)
    return formula



def satisfying_assignment(formula):
    """
    Find a satisfying assignment for a given CNF formula.
    Returns that assignment if one exists, or None otherwise.

    >>> satisfying_assignment([])
    {}
    >>> x = satisfying_assignment([[('a', True), ('b', False), ('c', True)]])
    >>> x.get('a', None) is True or x.get('b', None) is False or x.get('c', None) is True
    True
    >>> satisfying_assignment([[('a', True)], [('a', False)]])
    """

    # choose the first element to start with
    if formula is None:
        return None
    # length of it equal to 0
    if len(formula)==0:
        return {}

    variable=formula[0][0][0]
    signs=[True, False]
    for sign in signs:
        assignment={variable:sign}

        #get the simplified version
        new_formula=simplify(formula, assignment)
        if new_formula is None:
            continue
        new_satisfy=satisfying_assignment(new_formula)
        if new_satisfy is not None:
            assignment.update(new_satisfy)
            return assignment
    return None



def only_in_desired_sessions(student_preferences):
    '''
    return formula that makes sure every student is only in his desired session
    Param: student_preference is a dictionary mapping each student to their room preferences
    return: cnf formula
    '''
    formula=[]

    if student_preferences is None:
        return []
    for student in student_preferences:
        clause=[]
        for room in student_preferences[student]:
            comb=(student+'_'+room, True)
            clause.append(comb)
        formula.append(clause)
    return formula

def getsubset(l, k):
    '''
    Params: l is a list including all of the elements
    k is the length of the desired subsets
    Return: return all subsets of length k in the form of list of sets
    '''

    if k==1:
        return [{i} for i in l]
    result=[]
    subsets=getsubset(l, k-1)
    for subset in subsets:
        for element in l:
            if element not in subset:
                result.append(subset|{element})
    return set(frozenset(i) for i in result)


def exactly_one_session(student_preferences, room_capacities):
    rooms=room_capacities.keys()
    roomcombs=getsubset(rooms, 2)
    print(roomcombs)
    formula=[]
    for student in student_preferences:
        for comb in roomcombs:
            comb=list(comb)
            clause=[]
            variable1=student+'_'+comb[0]
            variable2=student+'_'+comb[1]
            literal1=(variable1, False)
            literal2=(variable2, False)
            clause.append(literal1)
            clause.append(literal2)
            formula.append(clause)
    return formula

def no_oversubscribed_sessions(student_preferences, room_capacities):
    students=student_preferences.keys()
    num_students=len(students)
    formula=[]
    for room in room_capacities:
        n=room_capacities[room]
        if n>=num_students:
            continue
        student_combs=getsubset(students, n+1)
        for student_comb in student_combs:
            clause=[(student+'_'+room, False) for student in student_comb]
            formula.append(clause)
    return formula

def boolify_scheduling_problem(student_preferences, room_capacities):
    """
    Convert a quiz-room-scheduling problem into a Boolean formula.

    student_preferences: a dictionary mapping a student name (string) to a set
                         of room names (strings) that work for that student

    room_capacities: a dictionary mapping each room name to a positive integer
                     for how many students can fit in that room

    Returns: a CNF formula encoding the scheduling problem, as per the
             lab write-up

    We assume no student or room names contain underscores.
    """
    return only_in_desired_sessions(student_preferences)+exactly_one_session(student_preferences, room_capacities)+no_oversubscribed_sessions(student_preferences, room_capacities)



if __name__ == '__main__':
    import doctest
    _doctest_flags = doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
    doctest.testmod(optionflags=_doctest_flags)


'basement''kitchen''penthouse'
'Alice', 'Bob', 'Charles', 'Dana'
