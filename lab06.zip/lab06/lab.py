# NO ADDITIONAL IMPORTS!
import doctest
from text_tokenize import tokenize_sentences


class Trie:
    def __init__(self, key_type):
        self.key_type = key_type
        self.children = dict()
        self.value = None

    def __setitem__(self, key, value):
        """
        Add a key with the given value to the trie, or reassign the associated
        value if it is already present in the trie.  Assume that key is an
        immutable ordered sequence.  Raise a TypeError if the given key is of
        the wrong type.
        """
        if not isinstance(key, self.key_type):
            raise TypeError

        cur = self
        for ch in key:
            ch = self.__transform_one_element(ch)
            child = cur.children.get(ch)
            if child is None:
                # ex. bet, e doesn't exist, first create a new node
                child = Trie(cur.key_type)
                # put it into the children dictionary of the current node
                cur.children[ch] = child
            cur = child
        cur.value = value

    def __getitem__(self, key):
        """
        Return the value for the specified prefix.  If the given key is not in
        the trie, raise a KeyError.  If the given key is of the wrong type,
        raise a TypeError.
        >>> t=Trie(str)
        >>> t["abc"]=1
        >>> t["acd"]=2
        >>> t["abc"]
        1
        >>> t["abd"]
        Traceback (most recent call last):
            ...
        KeyError
        >>> t[1]
        Traceback (most recent call last):
            ...
        TypeError
        """
        node = self.get_trie_node(key)

        if node and node.value is not None:
            return node.value
        raise KeyError

    def __delitem__(self, key):
        """
        Delete the given key from the trie if it exists. If the given key is not in
        the trie, raise a KeyError.  If the given key is of the wrong type,
        raise a TypeError.
        >>> t=Trie(str)
        >>> t['bat']=7
        >>> t['bark']=':)'
        >>> t['bar']=3
        >>> del t['bar']
        >>> t['bar']
        Traceback (most recent call last):
            ...
        KeyError
        >>> del t['foo']
        Traceback (most recent call last):
            ...
        KeyError
        >>> del t[3]
        Traceback (most recent call last):
            ...
        TypeError



        """
        node = self.get_trie_node(key)
        if not node or node.value is None:
            raise KeyError
        node.value = None

    def __contains__(self, key):
        """
        Is key a key in the trie? return True or False.  If the given key is of
        the wrong type, raise a TypeError.
        >>> t=Trie(str)
        >>> t['bat']=7
        >>> t['bark']=':)'
        >>> t['bar']=3
        >>> 'bar' in t
        True
        >>> 'barking' in t
        False
        >>> 'ba' in t
        False
        """
        node = self.get_trie_node(key)
        return node and node.value is not None

    def get_trie_node(self, key):
        """
        get trie node
        """
        if not isinstance(key, self.key_type):
            raise TypeError
        current = self
        for ch in key:
            ch = self.__transform_one_element(ch)
            #.get can return none if it doesn't exist
            child = current.children.get(ch)
            if child is None:
                return None
            current = child
        return current

    # def __len__(self):
    #     for ix, _ in enumerate(self):
    #         pass
    #     return ix+1

    def __iter__(self):
        """
        Generator of (key, value) pairs for all keys/values in this trie and
        its children.  Must be a generator!
        """
        return self.__all_word_under_trie_node([])

    def __all_word_under_trie_node(self, path):
        """
        all_word_under_trie_node
        """
        if self.value is not None:
            yield self.__transform_path(path), self.value
        #dfs search
        for ch, child in self.children.items():
            path.append(ch[0])
            #yield from the generator
            yield from child.__all_word_under_trie_node(path)
            path.pop()

    def __transform_one_element(self, e):
        # because the rec10 type is either string or tuple
        if self.key_type == str:
            return e
        return e,

    def __transform_path(self, path):
        #path is a list
        # change the path to the desired rec10 typr
        if self.key_type == str:
            return "".join(path)
        return tuple(path)


def make_word_trie(text):
    """
    Given a piece of text as a single string, create a Trie whose keys are the
    words in the text, and whose values are the number of times the associated
    word appears in the text
    >>> trie=make_word_trie('Today I am happy. Are you happy?')
    >>> trie['happy']
    2
    >>> 'arr' in trie
    False
    """
    trie = Trie(str)
    sentences = tokenize_sentences(text)
    for sentence in sentences:
        # get each individual word
        words = sentence.split(" ")
        for word in words:
            if word in trie:
                trie[word] += 1
            else:
                trie[word] = 1
    return trie


def make_phrase_trie(text):
    """
    Given a piece of text as a single string, create a Trie whose keys are the
    sentences in the text (as tuples of individual words) and whose values are
    the number of times the associated sentence appears in the text.
    >>> trie=make_phrase_trie('Sea. Sea. Sea. Do you see the sea?')
    >>> trie[('sea',)]
    3
    >>> trie[('do', 'you', 'see', 'the', 'sea')]
    1
    >>> trie[('do',)]
    Traceback (most recent call last):
        ...
    KeyError
    """
    trie = Trie(tuple)
    sentences = tokenize_sentences(text)
    for sentence in sentences:
        words = tuple(sentence.split(" "))
        if words in trie:
            trie[words] += 1
        else:
            trie[words] = 1
    return trie


def autocomplete(trie, prefix, max_count=None):
    """
    Return the list of the most-frequently occurring elements that start with
    the given prefix.  Include only the top max_count elements if max_count is
    specified, otherwise return all.

    Raise a TypeError if the given prefix is of an inappropriate type for the
    trie.

    >>> t=Trie(str)
    >>> t['bat']=2
    >>> t['bark']=1
    >>> t['bar']=1
    >>> autocomplete(t, 'ba', 1)
    ['bat']
    >>> autocomplete(t, 'b', 3)
    ['bat', 'bar', 'bark']
    """
    if not isinstance(prefix, trie.key_type):
        raise TypeError
    node = trie.get_trie_node(prefix)
    if node is None:
        return []
    sorted_list = sorted([e for e in node], key=lambda x: x[1], reverse=True)
    if max_count is None or max_count >= len(sorted_list):
        return [prefix + k for k, _ in sorted_list]

    return [prefix + k for k, _ in sorted_list[0: max_count]]


def autocorrect(trie, prefix, max_count=None):
    """
    Return the list of the most-frequent words that start with prefix or that
    are valid words that differ from prefix by a small edit.  Include up to
    max_count elements from the autocompletion.  If autocompletion produces
    fewer than max_count elements, include the most-frequently-occurring valid
    edits of the given word as well, up to max_count total elements.
    >>> t=Trie(str)
    >>> t['bat']=2
    >>> t['bark']=1
    >>> t['bar']=1
    >>> t['bra']=8
    >>> autocorrect(t, 'bar', 3)
    ['bar', 'bark', 'bra']
    >>> autocorrect(t, 'bar', 5)
    ['bar', 'bark', 'bra', 'bat']
    """
    autocomplete_list = autocomplete(trie, prefix, max_count)
    len1 = len(autocomplete_list)

    # if requirement of maxcount already satisfied
    if max_count == len1:
        return autocomplete_list

    #turn into a set to check if e[0] in autocomplete
    autocomplete_set = set(autocomplete_list)
    autocorrect_list = [e for e in trie if e[0] not in autocomplete_set and is_k_edit_distance(e[0], prefix, 1)]
    autocorrect_list = sorted(autocorrect_list, key=lambda x: x[1], reverse=True)
    len2 = len(autocorrect_list)
    if max_count is None or max_count >= len1 + len2:
        for e in autocorrect_list:
            autocomplete_list.append(e[0])
    else:
        for e in autocorrect_list[:max_count - len1]:
            autocomplete_list.append(e[0])
    return autocomplete_list


def is_k_edit_distance(w1, w2, k):
    """
    check if the two words w1 and w2 are within k distance
    """
    if abs(len(w1) - len(w2)) > k:
        return False

    dist = edit_distance(w1, w2)
    return dist == k


def edit_distance(w1, w2):

    # Damerau%E2%80%93Levenshtein_distance
    """
    w1, w2 are two words
    returns the number of operations to get from one word to the other word
    """
    n, m = len(w1), len(w2)

    #dp is initially (m+1)*(n+1) matrix of zeros
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    #dp[i][j] is the edit distance between w1[0:i-1] and w2[0:j-1]

    # if the length of one of the words is 0, then the number of operation is just the length of the other word
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j

    for i in range(1, n + 1):
        for j in range(1, m + 1):

            # cost for single character replacement
            # cost=1 if ex. abc and abd
            # cost=0 if ex. abc and abc
            cost = 0 if w1[i - 1] == w2[j - 1] else 1
            dp[i][j] = min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)

            #the case of transposition
            # if it is the case of ex. abc and acb
            if i > 1 and j > 1 and w1[i - 1] == w2[j - 2] and w1[i - 2] == w2[j - 1]:
                dp[i][j] = min(dp[i][j], dp[i - 2][j - 2] + 1)
    return dp[n][m]


def word_filter(trie, pattern):
    """
    Return list of (word, freq) for all words in trie that match pattern.
    pattern is a string, interpreted as explained below:
         * matches any sequence of zero or more characters,
         ? matches any single character,
         otherwise char in pattern char must equal char in word.
    >>> t=Trie(str)
    >>> t['bat']=2
    >>> t['bark']=1
    >>> t['bar']=1
    >>> set(word_filter(t,"???"))=={('bat', 2), ('bar', 1)}
    True
    >>> set(word_filter(t, "*"))=={('bat', 2), ('bar', 1), ('bark', 1)}
    True
    >>> set(word_filter(t, "ba??"))=={('bark', 1)}
    True
    >>> set(word_filter(t, "*a*"))=={('bat', 2), ('bar', 1), ('bark', 1)}
    True
    """
    pattern = simplify_pattern(pattern)
    res = set()
    find_all_matched_wildcard(trie, pattern, 0, [], res)
    return [e for e in res]


def simplify_pattern(pattern):
    '''
    if there are multiple continuous *s, shrink them into one *
    '''
    builder = []
    i, n = 0, len(pattern)
    while i < n:
        if pattern[i] == '*':
            builder.append('*')
            i += 1
            # reach the last one that is a connected *
            # ex. a ***b --- a*b
            while i < n and pattern[i] == '*':
                i += 1
        else:
            builder.append(pattern[i])
            i += 1
    return "".join(builder)


def find_all_matched_wildcard(trie, pattern, index, path, res):
    '''
    Params: trie is the trie structure
    pattern is the given wildcard, ex. a*b*
    index is which index in the pattern we are trying to match
    path is the current path
    res is the result set
    '''
    if index == len(pattern):
        if trie.value is not None:
            res.add(("".join(path), trie.value))
        return

    if pattern[index] == '?':
        for ch, child in trie.children.items():
            path.append(ch)
            find_all_matched_wildcard(child, pattern, index + 1, path, res)
            path.pop()
    elif pattern[index] == '*':
        # the case of matching 0 word to *
        # each layer is adding 0 or 1
        find_all_matched_wildcard(trie, pattern, index + 1, path, res)
        for ch, child in trie.children.items():
            path.append(ch)
            find_all_matched_wildcard(child, pattern, index, path, res)
            path.pop()
    else:
        child = trie.children.get(pattern[index])
        if child is not None:
            path.append(pattern[index])
            find_all_matched_wildcard(child, pattern, index + 1, path, res)
            path.pop()


# you can include test cases of your own in the block below.
if __name__ == "__main__":
    doctest.testmod()
    with open("Alice.txt", encoding="utf-8") as f:
        text_Alice = f.read()
    with open("meta.txt", encoding="utf-8") as f:
        text_meta = f.read()
    with open("dracula.txt", encoding="utf-8") as f:
        text_dracula = f.read()
    with open("Pride.txt", encoding="utf-8") as f:
        text_pride = f.read()
    with open("two.txt", encoding="utf-8") as f:
        text_two = f.read()



    # problem 1
    # Alice_trie=make_phrase_trie(text_Alice)
    # Alice_word=make_word_trie(text_Alice)
    # sorted_Alice_trie=[x for x in sorted(Alice_trie, key=lambda x:x[1], reverse=True)]
    # result=[]
    # for i in range(6):
    #     result.append(sorted_Alice_trie[i][0])
    # print(result)

    # problem 2
    # meta_word=make_word_trie(text_meta)
    # print(autocomplete(meta_word, 'gre', 6))

    # problem 3
    # print(word_filter(meta_word, 'c*h'))

    # problem 4
    # two_word=make_word_trie(text_two)
    # print(word_filter(two_word,'r?c*t'))


    # problem 5
    # print(autocorrect(Alice_word, 'hear', 12))

    # problem 6
    # pride_word=make_word_trie(text_pride)
    # print(autocorrect(pride_word, 'hear'))
    # problem 7
    # dracula_word=make_word_trie(text_dracula)
    # print(len(dracula_word))


    # problem 8
    # count=0
    # for k,v in dracula_word:
    #     count+=v
    # print(count)

    # problem 9
    # print(len(Alice_trie))

    # problem 10
    # count=0
    # for k, v in Alice_trie:
    #     count+=v
    # print(count)



