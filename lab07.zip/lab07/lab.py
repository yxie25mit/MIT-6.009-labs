import doctest


# NO ADDITIONAL IMPORTS ALLOWED!
# You are welcome to modify the classes below, as well as to implement new
# classes and helper functions as necessary.


class Symbol:
    def __add__(self, right):
        return Add(self, right)

    def __radd__(self, left):
        return Add(left, self)

    def __sub__(self, right):
        return Sub(self, right)

    def __rsub__(self, left):
        return Sub(left, self)

    def __mul__(self, right):
        return Mul(self, right)

    def __rmul__(self, left):
        return Mul(left, self)

    def __truediv__(self, right):
        return Div(self, right)

    def __rtruediv__(self, left):
        return Div(left, self)

    def __pow__(self, power, modulo=None):
        return Pow(self, power)

    def __rpow__(self, other):
        return Pow(other, self)


class Var(Symbol):
    def __init__(self, n):
        """
        Initializer.  Store an instance variable called `name`, containing the
        value passed in to the initializer.
        """
        self.name = n
        self.pred = 0

    def __str__(self):
        return self.name

    def __repr__(self):
        return "Var(" + repr(self.name) + ")"

    def deriv(self, x):
        if x == self.name:
            return Num(1)
        return Num(0)

    def simplify(self):
        return self

    def eval_(self, mapping):
        if self.name in mapping:
            return Num(mapping[self.name])
        return self


class Num(Symbol):
    def __init__(self, n):
        """
        Initializer.  Store an instance variable called `n`, containing the
        value passed in to the initializer.
        """
        self.n = n
        self.pred = 0

    def __str__(self):
        return str(self.n)

    def __repr__(self):
        return "Num(" + repr(self.n) + ")"

    def deriv(self, x):
        return Num(0)

    def __eq__(self, other):
        if isinstance(other, (int, float)):
            return self.n == other
        if isinstance(other, Num):
            return self.n == other.n
        return False

    def simplify(self):
        return self

    def eval_(self, mapping):
        return self


def compare(v1, v2):
    return v1.pred - v2.pred


def get_left_right(bin_op, act):
    cmp_l = compare(bin_op, bin_op.left)
    cmp_r = compare(bin_op, bin_op.right)
    left = act(bin_op.left) if cmp_l > 0 or (cmp_l == 0 and bin_op.is_left_associative) else f"({act(bin_op.left)})"
    if bin_op.is_symmetric:
        right = act(bin_op.right) if cmp_r >= 0 else f"({act(bin_op.right)})"
    else:
        right = act(bin_op.right) if cmp_r > 0 or (
                    cmp_r == 0 and not bin_op.is_left_associative) else f"({act(bin_op.right)})"
    return left, right


def get_str(bin_op, op_str):
    left, right = get_left_right(bin_op, str)
    return f"{left} {op_str} {right}"


def get_repr(bin_op, op_repr):
    left, right = get_left_right(bin_op, repr)
    return f"{op_repr}({left}, {right})"


class BinOp(Symbol):
    def __init__(self, left, right):
        self.left = BinOp.transform(left)
        self.right = BinOp.transform(right)

    @classmethod
    def transform(cls, val):
        if isinstance(val, (int, float)):
            return Num(val)
        if isinstance(val, str):
            return Var(val)
        return val

    def eval(self, mapping):
        result = self.eval_(mapping).simplify()
        if isinstance(result, Num):
            return result.n

    def eval_(self, mapping):
        left = self.left.eval_(mapping)
        right = self.right.eval_(mapping)
        return self.__class__(left, right)


class Add(BinOp):
    def __init__(self, left, right):
        super().__init__(left, right)
        self.pred = 3
        self.is_symmetric = True
        self.is_left_associative = True

    def __str__(self):
        return get_str(self, "+")

    def __repr__(self):
        return get_repr(self, "Add")

    def deriv(self, x):
        return Add(self.left.deriv(x), self.right.deriv(x))

    def simplify(self):
        left = self.left.simplify()
        right = self.right.simplify()
        if left == 0:
            return right
        if right == 0:
            return left
        if isinstance(left, Num) and isinstance(right, Num):
            return Num(left.n + right.n)
        return Add(left, right)


class Sub(BinOp):
    def __init__(self, left, right):
        super().__init__(left, right)
        self.pred = 3
        self.is_symmetric = False
        self.is_left_associative = True

    def __str__(self):
        return get_str(self, "-")

    def __repr__(self):
        return get_repr(self, "Sub")

    def deriv(self, x):
        return Sub(self.left.deriv(x), self.right.deriv(x))

    def simplify(self):
        left = self.left.simplify()
        right = self.right.simplify()
        if right == 0:
            return left
        if isinstance(left, Num) and isinstance(right, Num):
            return Num(left.n - right.n)
        return Sub(left, right)


class Mul(BinOp):
    def __init__(self, left, right):
        super().__init__(left, right)
        self.pred = 2
        self.is_symmetric = True
        self.is_left_associative = True

    def __str__(self):
        return get_str(self, "*")

    def __repr__(self):
        return get_repr(self, "Mul")

    def deriv(self, x):
        return Add(Mul(self.left.deriv(x), self.right),
                   Mul(self.left, self.right.deriv(x)))

    def simplify(self):
        left = self.left.simplify()
        right = self.right.simplify()
        if left == 0 or right == 0:
            return Num(0)
        if left == 1:
            return right
        if right == 1:
            return left
        if isinstance(left, Num) and isinstance(right, Num):
            return Num(left.n * right.n)
        return Mul(left, right)


class Div(BinOp):
    def __init__(self, left, right):
        super().__init__(left, right)
        self.pred = 2
        self.is_symmetric = False
        self.is_left_associative = True

    def __str__(self):
        return get_str(self, "/")

    def __repr__(self):
        return get_repr(self, "Div")

    def deriv(self, x):
        return Div(Sub(Mul(self.left.deriv(x), self.right),
                       Mul(self.left, self.right.deriv(x))),
                   Mul(self.right, self.right))

    def simplify(self):
        left = self.left.simplify()
        right = self.right.simplify()
        if left == 0:
            return Num(0)
        if right == 1:
            return left
        if isinstance(left, Num) and isinstance(right, Num):
            return Num(left.n / right.n)
        return Div(left, right)


class Pow(BinOp):
    def __init__(self, left, right):
        super().__init__(left, right)
        self.pred = 1
        self.is_symmetric = False
        self.is_left_associative = False

    def __str__(self):
        return get_str(self, "**")

    def __repr__(self):
        return get_repr(self, "Pow")

    def deriv(self, x):
        if not isinstance(self.right, Num):
            raise TypeError
        n = self.right
        return Mul(Mul(n, Pow(self.left, n - 1)),
                   self.left.deriv(x))

    def simplify(self):
        left = self.left.simplify()
        right = self.right.simplify()
        if right == 0:
            return Num(1)
        if right == 1:
            return left
        if left == 0:
            return left
        if isinstance(left, Num) and isinstance(right, Num):
            return Num(left.n ** right.n)
        return Pow(left, right)


def sym(expr):
    tokens = tokenize(expr)
    return parse(tokens)


def tokenize(expr):
    tokens = []
    index, n = 0, len(expr)
    while index < n:
        ch = expr[index]
        j = index + 1
        if '0' <= ch <= '9' or (ch == '-' and expr[j] != ' '):
            while j < n and '0' <= expr[j] <= '9':
                j += 1
            tokens.append(expr[index:j])
        elif ch == '*' and expr[j] == '*':
            j += 1
            tokens.append(expr[index:j])
        elif ch != ' ':  # ch in "+-/*" or ch is var
            tokens.append(ch)
        index = j
    return tokens


def parse(tokens):
    val_stack = []
    opt_stack = []
    for token in tokens:
        if token == '(':
            opt_stack.append(token)
        elif token == ')':
            while opt_stack[-1] != '(':
                process(val_stack, opt_stack.pop())
            opt_stack.pop()
        elif token in "+-**/":
            while need_process(opt_stack, token):
                process(val_stack, opt_stack.pop())
            opt_stack.append(token)
        else:
            val = Num(int(token)) if token.lstrip('-').isdigit() else Var(token)
            val_stack.append(val)
    while opt_stack:
        process(val_stack, opt_stack)
    return val_stack[0]


def process(val_stack, op):
    r = val_stack.pop()
    l = val_stack.pop()
    if op == '+':
        val_stack.append(Add(l, r))
    elif op == '-':
        val_stack.append(Sub(l, r))
    elif op == '*':
        val_stack.append(Mul(l, r))
    elif op == '/':
        val_stack.append(Div(l, r))
    else:
        val_stack.append(Pow(l, r))


def need_process(opt_stack, opt):
    return opt_stack and opt_stack[-1] != '(' and compare(opt_stack[-1], opt) <= 0


if __name__ == "__main__":
    doctest.testmod()
